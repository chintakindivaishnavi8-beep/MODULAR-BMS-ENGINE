
#define POT_PIN 34
#define POT_PIN 35
#define POT_PIN 32
#define POT_PIN 33

#define RED_LED 2
#define YELLOW_LED 4
#define GREEN_LED 5

float voltage[4];

void setup(){
  pinMode(RED_LED,OUTPUT);
  pinMode(YELLOW_LED,OUTPUT);
  pinMode(GREEN_LED,OUTPUT);

  Serial.begin(115200);
  Serial.println("");
}

void loop() {
  // put your main code here, to run repeatedly:
  delay(10); // this speeds up the simulation
}
