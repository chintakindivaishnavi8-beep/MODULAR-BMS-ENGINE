#define BLYNK_TEMPLATE_ID "TMPL3o6OG5pD9"
#define BLYNK_TEMPLATE_NAME "SMART BMS"
#define BLYNK_AUTH_TOKEN "cvSEAj6IxKVz_8MSSmCssTXz9eY6EiIt"
#define BLYNK_PRINTSerial 

#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <BlynkSimpleEsp32.h>

char ssid[]="Wokwi-GUEST";
char pass[]="";
BlynkTimer timer;
LiquidCrystal_I2C lcd(0x27,16,2);

const int BUZZER_PIN=19;

enum BMSState{
  NORMAL,
  DEGRADED,
  FAILSAFE,
  SHUTDOWN
};
  
BMSState systemState = NORMAL;
bool sensorFault = false;
bool relayEnabled = true;

unsigned long lastCheckTime = 0;
const unsigned long CHECK_INTERVAL = 100;

unsigned long lastLCDUpdate = 0;

const uint8_t CELL_COUNT = 4;
const uint8_t CELL_PINS[CELL_COUNT]={34,35,32,33};
const uint8_t RED_LED = 25;
const uint8_t GREEN_LED = 26;
const uint8_t YELLOW_LED = 27;
 #define BUZZER  19;
 #define RELAY 18;
 float v1,v2,v3;
 int p1,p2,p3;

int adcValue[CELL_COUNT];
float cellVoltage[CELL_COUNT];
String status;
int statusCode;

float readVoltage(int pin){
  int raw = analogRead(pin);
  return(raw / 4095.0)*3.3;
}
int getPercent(float V){
  return constrain(map(V*100,0,330,0,100),0,100);
}

void updateLCD(float strongest,float weakest,float imbalance);
float SOC =50.0;
void setup(){
  pinMode(RED_LED,OUTPUT);
  pinMode(GREEN_LED,OUTPUT);
  pinMode(YELLOW_LED,OUTPUT);

  pinMode(18, OUTPUT);

  pinMode(BUZZER_PIN,OUTPUT);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0,0);
  lcd.print("BMS Starting...");
  lcd.setCursor(0,1);
  lcd.print("System Ready");
  Blynk.begin(BLYNK_AUTH_TOKEN,ssid,pass);
  Serial.begin(115200);
  Serial.println("BMS Started");
}

void loop() {
  Blynk.run();
  timer.run();
for(int i = 0; i<CELL_COUNT;i++){
int raw = analogRead (CELL_PINS[i]);
adcValue[i]=raw;
cellVoltage[i] = (raw/4095.0)*3.3;
  }

float strongest = cellVoltage[0];
float weakest = cellVoltage[0];
int strongestCell = 0;
int weakCell = 0;
for(int i = 1; i<CELL_COUNT;i++){
  if(cellVoltage[i]>strongest){
    strongest = cellVoltage[i];
    strongestCell = i;
  }
  if(cellVoltage[i]<weakest){
    weakest = cellVoltage[i];
    weakCell=i;
  }
}
sensorFault = false;
for(int i=0;i<CELL_COUNT;i++){
 if(adcValue[i]<=5||adcValue[i]>=4090){
  sensorFault=true;
 }   
}
  if(sensorFault){
    digitalWrite(18,LOW);
  }
float imbalance = strongest - weakest;
 
 if(imbalance>=0.25){
statusCode = 2 ;//FAIL SAFE/HIGH IMBALANCE
 }else if(imbalance>=0.15){
  statusCode = 1;//DEGRADED/NORMAL
 }else{
  statusCode = 0;//NORMAL
 }
 
 v1=cellVoltage[0];
 v2=cellVoltage[1];
 v3=cellVoltage[2];
 p1=getPercent(cellVoltage[0]);
 p2=getPercent(cellVoltage[1]);
 p3=getPercent(cellVoltage[2]);
 

digitalWrite(RED_LED,LOW);
digitalWrite(GREEN_LED,LOW);
digitalWrite(YELLOW_LED,LOW);
digitalWrite(BUZZER_PIN,LOW);
digitalWrite(18,LOW);

 if (p1 < 30 || p2 < 30 || p3 < 30){ 
  digitalWrite(RED_LED,HIGH);
  digitalWrite(BUZZER_PIN,HIGH);
  Serial.println("Status:FAILSAFE");
  digitalWrite(18,HIGH);
 }
  else if (p1 > 80 || p2 > 80 || p3 > 80){
  digitalWrite(YELLOW_LED,HIGH);
  digitalWrite(BUZZER_PIN,HIGH);
  Serial.println("Status:DEGRADED");
  digitalWrite(18,LOW);
 }
 else {
  digitalWrite(GREEN_LED,HIGH);
  Serial.println("Status:NORMAL");
  digitalWrite(18,LOW);
 }
 if(millis()-lastLCDUpdate>1000){
  lastLCDUpdate=millis();
  updateLCD(strongest,weakest,imbalance);
 }
updateLCD(strongest,weakest,imbalance);



Blynk.virtualWrite(V0, cellVoltage[0]);
Blynk.virtualWrite(V1, cellVoltage[1]);
Blynk.virtualWrite(V2, cellVoltage[2]);
Blynk.virtualWrite(V3, cellVoltage[3]);

Blynk.virtualWrite(V4, imbalance);
Blynk.virtualWrite(V5, SOC);

if (imbalance >= 0.25) {
  Blynk.virtualWrite(V6, "WARNING");
} else {
  Blynk.virtualWrite(V6, "NORMAL");
}

int riskScore;

if (imbalance >= 0.25) {
  riskScore = 80;
} else if (imbalance >= 0.15) {
  riskScore = 50;
} else {
  riskScore = 10;
}

Blynk.virtualWrite(V7, riskScore);

if (riskScore >= 80) {
  Blynk.virtualWrite(V8, "Check cell imbalance");
} else if (riskScore >= 50) {
  Blynk.virtualWrite(V8, "Monitor battery");
} else {
  Blynk.virtualWrite(V8, "Battery normal");
}

Blynk.virtualWrite(V9, millis() / 1000);

static unsigned int faultCount = 0;
static bool previousFault = false;

bool currentFault = (imbalance >= 0.25);

if (currentFault && !previousFault) {
  faultCount++;
}

previousFault = currentFault;

Blynk.virtualWrite(V10, faultCount);
 Serial.println("-----------");
 Serial.print("C1:"); Serial.print(v1,2);Serial.print("V ");
 Serial.print("C2:");Serial.print(v2,2);Serial.print("V ");
 Serial.print("C3:");Serial.print(v3,2);

 Serial.println(status);
}
void updateLCD(float strongest,float weakest,float imbalance){
  char line1[17];
  char line2[17];
  
  lcd.setCursor (0,0);
  lcd.print("I:");
  lcd.print(imbalance,2);
  lcd.print("S:");
  lcd.print(strongest,2);
  lcd.print("V");

  lcd.setCursor (0,1);
  lcd.print("W:");
  lcd.print(weakest,2);
  lcd.print("V SOC:");
  int avgSOC= (p1+p2+p3+getPercent(cellVoltage[3]))/4;
  const char*st="NRM";
  if(statusCode==1)st="DEG";
  if(statusCode==2)st="FAIL";
  snprintf(line1,17,"I:%.2fS:%.2fV",imbalance,strongest);
   snprintf(line1,17,"W:%.2f%d%%%s",weakest,avgSOC,st);


  lcd.print(avgSOC);
  lcd.print("% ");

}


