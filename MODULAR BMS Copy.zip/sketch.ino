
#include<Aurduino.h>

const uint8_t CELL_COUNT = 4;
const uint8_t CELL_PINS[CELL_COUNT]={34,35,32,33};

float cellVoltage[CELL_COUNT];

void setup(){
  pinMode(RED_LED,OUTPUT);
  pinMode(YELLOW_LED,OUTPUT);
  pinMode(GREEN_LED,OUTPUT);

  Serial.begin(115200);
  Serial.println("");
}

void loop() {
  // put your main code here, to run repeatedly:
  delay(10); // this speeds up the simulation
}
